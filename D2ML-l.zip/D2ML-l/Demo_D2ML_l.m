
addpath(genpath(pwd))


% dataset
dataname='Arts';
data = importdata('Arts.mat');

% parameter settings

param.j=10; % label observation rates
param.lambda=10^-5; 


% out_result: the predicion performance for test data.

[in_result, out_result] = run_arts(param, data);
   


 

