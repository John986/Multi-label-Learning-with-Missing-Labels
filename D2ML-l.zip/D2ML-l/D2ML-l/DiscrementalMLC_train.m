function[Wtplus]=DiscrementalMLC_train(Xtrain, Ytrain, J, lambda)
[n, m]=size(Ytrain);
[~, d]=size(Xtrain);
X=cell(m, 1);
for i=1:m
    tempindex=find(Ytrain(:, i)>0);
    X{i}=Xtrain(tempindex, :);    
end

Wt=eye(d, m);
Flag=true;
iteration=1;
while Flag && iteration <25
    
    Wtplus=optimize_surrogate(Xtrain, X, Ytrain, J, Wt, lambda);
    fvalue=objvalue(Xtrain, Ytrain, X, J, lambda, Wt);
    if norm(Wtplus-Wt, 'fro')/norm(Wt, 'fro') <10^-3
        Flag=false;
    else
       iteration=iteration+1; 
       Wt=Wtplus;
    end
     
    
    %%
    fid = fopen('Entertainment.txt', 'at');  
    fprintf(fid,'%f\n', fvalue);  
    fclose(fid);  

    
    
    
end
end

