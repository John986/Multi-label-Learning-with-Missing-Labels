function[fvalue]=objvalue(Xtrain, Ytrain, X, J, lambda, Wplus)
[d, m] = size(Wplus);
% Function value (residual)
term1=1/2* norm(J.*(Xtrain*Wplus-Ytrain), 'fro')^2;
Sabs=0;
for i=1:m
  S=svd(X{i}*Wplus, 'econ');
  Sabs=Sabs+sum(abs(S));
end

term2=lambda*Sabs;

S1=svd(Xtrain*Wplus, 'econ');

term3=lambda*sum(abs(S1));
fvalue = term1+term2-term3;


end