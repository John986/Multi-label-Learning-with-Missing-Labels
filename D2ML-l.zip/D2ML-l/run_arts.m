function [in_result, out_result] = run_arts(param, data)

n=size(data.features, 1);
ntrain=floor(0.6*n);
% ntest=floor(0.2*n);


 out_result = [];
 in_result = [];

    for j=param.j      
        for kk = 1:5
            s = RandStream.create('mt19937ar','seed',kk);
            RandStream.setGlobalStream(s);
            ind=randperm(n);
            
            Xtrn =data.features(ind(1:ntrain), :);
            Ytrn = data.labels(ind(1:ntrain), :);
%             Xtst =data.features(ind(end-ntest+1:end), :);
%             Ytst = data.labels(ind(end-ntest+1:end),:);
            Xtst =data.features(ind(ntrain+1:end), :);
            Ytst = data.labels(ind(ntrain+1:end),:);

            [J] = genObv( Ytrn, 0.1*j);
            tic;
            W=DiscrementalMLC_train(Xtrn, Ytrn, J, param.lambda);   
            tm = toc;
            zz = mean(Ytst,2);
            Ytst(:,zz==-1) = [];
            Xtst(:,zz==-1) = [];
            tstv = Xtst*W;
            tstv=tstv';
            Ytst=Ytst';
            ret =  evalt(tstv,Ytst, (max(tstv(:))-min(tstv(:)))/2);
            ret.time = tm;
            out_result = [out_result;ret];
            zz = mean(Ytrn, 2);
            Ytrn(:,zz==-1) = [];
            Xtrn(:,zz==-1) = [];
            tstv2 = Xtrn*W;
            tstv2=tstv2';
            Ytrn=Ytrn';
            ret =  evalt(tstv2,Ytrn, (max(tstv2(:))-min(tstv2(:)))/2);
            in_result = [in_result;ret];
            
        end
    end
end
