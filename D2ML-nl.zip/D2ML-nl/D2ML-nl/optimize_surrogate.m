
function[Wplus]=optimize_surrogate(Xtrain, X, Ytrain, J, W, lambda)

Data.Xtrain=Xtrain;
Data.X=X;
Data.Ytrain=Ytrain;
Data.J=J;
Data.W=W;
Data.lambda=lambda;


[d, m]=size(W);
x0=reshape(W, d*m ,1);
 out=ncg(@(x) optimizeW(x, Data), x0, 'RelFuncTol', 1e-5, 'StopTol', 1e-8, ...)
'MaxFuncEvals', 1000, 'Display', 'final');
Wplus=reshape(out.X, d, m);

end

