
function [f,g] = optimizeW(x,Data)
% Data setup
[d, m] = size(Data.W);
Wplus=reshape(x, d, m);


% Function value (residual)
term1=1/2* norm(Data.J.*(Data.Xtrain*Wplus-Data.Ytrain), 'fro')^2;

Sabs=0;
for i=1:m
  S=svd(Data.X{i}*Wplus, 'econ');
  Sabs=Sabs+sum(abs(S));
end

term2=Data.lambda*Sabs;


Normgradient=subgradient_nuclearnorm(Data.Xtrain*Data.W);
term3=Data.lambda*trace(Wplus'*Data.Xtrain'*Normgradient);

f = term1+term2-term3;

% First derivatives computed in matrix form
gterm1=Data.Xtrain'*(Data.J.*(Data.Xtrain*Wplus-Data.Ytrain));
gterm2=zeros(d, m);
for i=1:m
   gterm2=gterm2+Data.X{i}'*subgradient_nuclearnorm(Data.X{i}*Wplus);
    
end

gterm2=Data.lambda*gterm2;

gterm3=Data.lambda*Data.Xtrain'*subgradient_nuclearnorm(Data.Xtrain*Data.W);

g=gterm1+gterm2-gterm3;

g=reshape(g, d*m, 1);


end