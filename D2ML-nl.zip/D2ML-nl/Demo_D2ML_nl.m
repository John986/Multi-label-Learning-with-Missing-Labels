addpath(genpath(pwd))

% dataset
dataname='tmc2007-500';
data = importdata('tmc2007-500.mat');

% parameter settings
param.j=10;
options.KernelType='Gaussian';
options.t=1;
options.d=1;
param.lambda=10^-4; 



% out_result: the predicion performance for test data.
[in_result, out_result] = run_arts(param, data, options);









